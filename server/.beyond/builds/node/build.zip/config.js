"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _default = exports.default = {
  "package": "server",
  "version": "0.0.1",
  "languages": {
    "default": "en",
    "supported": ["en", "es"]
  },
  "environment": "development",
  "global.css": true,
  "params": {},
  "ssr": {},
  "backend": {}
};